<?php 

	class Pakaian {
		public $warna,
			   $ukuran,
			   $bahan,
			   $harga;

		public function __construct($warna ="warna",$ukuran ="ukuran",$bahan = "bahan", $harga = 0) {
			$this->warna = $warna;
			$this->ukuran = $ukuran;
			$this->bahan = $bahan;
			$this->harga = $harga; 
		}

		public function getbuy(){
			return "$this->ukuran,$this->bahan";
		}

		public function getinfoPakaian(){
			$str = " {$this->warna} {$this->getbuy()} (RP.{$this->harga})";
			return $str;
		}
		

	}

	class celana extends Pakaian {
		public $jmlpcs;

		public function __construct( $warna ="warna",$ukuran ="ukuran",$bahan = "bahan",$harga = 0 ,$jmlpcs = 0 ){

			parent::__construct($warna , $ukuran , $bahan , $harga);

			$this->jmlpcs = $jmlpcs;
		}

		public function getinfoPakaian(){
			$str = "Celana : ". parent::getinfoPakaian()." ". "{$this->jmlpcs}/Pcs.";
			return $str;
		}
	}

	class baju extends Pakaian {
		public $jmlbuah;

		public function __construct( $warna ="warna",$ukuran ="ukuran",$bahan = "bahan",$harga = 0 ,$jmlbuah = 0  ){

			parent::__construct( $warna, $ukuran, $bahan, $harga);

			$this->jmlbuah = $jmlbuah;
		}

		public function getinfoPakaian(){
			$str = "Baju : " . parent::getinfoPakaian(). " ". "{$this->jmlbuah}/buah.";
			return $str;
		}
	}


	$celana = new celana("Navy", "L", "Waterproof", 50000, 1);
	$baju = new baju("Hijau","XL", "Katun", 75000, 2);

	echo $celana->getinfoPakaian();
	echo "<br>";
	echo $baju->getinfoPakaian();
	echo "<br>";

	


?>




 